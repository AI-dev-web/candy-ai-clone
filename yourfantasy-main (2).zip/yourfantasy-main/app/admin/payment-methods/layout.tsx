import type { ReactNode } from "react"

export default function PaymentMethodsLayout({ children }: { children: ReactNode }) {
  return <>{children}</>
}
