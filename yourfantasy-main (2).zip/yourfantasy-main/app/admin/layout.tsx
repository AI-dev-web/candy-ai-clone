"use client"

import { Suspense, type ReactNode } from "react"
import { SidebarProvider } from "@/components/sidebar-context"
import AdminSidebarContent from "@/components/admin-sidebar-content"
import AdminMobileNav from "@/components/admin-mobile-nav"
import Link from "next/link"
import { ChevronLeft, Menu, Bell, Search, User, Settings } from "lucide-react"
import { ErrorBoundary } from "@/components/error-boundary"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "@/components/theme-toggle"

function AdminHeader() {
  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-4 lg:px-6 flex items-center justify-between shadow-sm">
      {/* Left side - Mobile menu and search */}
      <div className="flex items-center space-x-4 flex-1">
        {/* Mobile menu trigger */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="p-6 border-b border-slate-200 dark:border-slate-700">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">A</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900 dark:text-white">Admin Panel</h1>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Management Dashboard</p>
                </div>
              </div>
              <Link
                href="/"
                className="mt-4 flex items-center text-sm text-slate-600 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to App
              </Link>
            </div>
            <div className="p-4 h-full overflow-y-auto">
              <Suspense fallback={<div className="p-4 text-center text-slate-500">Loading...</div>}>
                <AdminSidebarContent />
              </Suspense>
            </div>
          </SheetContent>
        </Sheet>

        {/* Logo and title for mobile */}
        <div className="flex items-center space-x-2 md:hidden">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">A</span>
          </div>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">Admin</h1>
        </div>

        {/* Search bar - hidden on mobile */}
        <div className="hidden lg:flex items-center space-x-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search users, characters, transactions..."
              className="pl-10 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 focus:border-purple-500 dark:focus:border-purple-400"
            />
          </div>
        </div>
      </div>

      {/* Right side - Actions and user menu */}
      <div className="flex items-center space-x-3">
        {/* Back to app link - desktop only */}
        <Link
          href="/"
          className="hidden lg:flex items-center text-sm text-slate-600 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to App
        </Link>

        {/* Theme toggle */}
        <ThemeToggle />

        {/* Notifications */}
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-red-500 hover:bg-red-600">
            3
          </Badge>
        </Button>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-10 w-10 rounded-full">
              <Avatar className="h-10 w-10">
                <AvatarImage src="/admin-avatar.png" alt="Admin" />
                <AvatarFallback className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">AD</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">Admin User</p>
                <p className="text-xs leading-none text-muted-foreground">admin@example.com</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600 dark:text-red-400">
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

function AdminSidebar() {
  return (
    <aside className="sidebar w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700 hidden md:flex flex-col shadow-lg">
      {/* Sidebar Header */}
      <div className="p-6 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-lg">A</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Admin Panel</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Management Dashboard</p>
          </div>
        </div>
      </div>

      {/* Sidebar Content - Scrollable */}
      <div className="flex-1 p-4 overflow-y-auto">
        <Suspense
          fallback={
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-12 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
              ))}
            </div>
          }
        >
          <AdminSidebarContent />
        </Suspense>
      </div>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
          <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">✓</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-900 dark:text-white">System Status</p>
            <p className="text-xs text-green-600 dark:text-green-400">All systems operational</p>
          </div>
        </div>
      </div>
    </aside>
  )
}

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="flex flex-col items-center space-y-4">
        <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center animate-pulse">
          <span className="text-white font-bold text-lg">A</span>
        </div>
        <div className="text-slate-600 dark:text-slate-400">Loading admin panel...</div>
      </div>
    </div>
  )
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <ErrorBoundary>
      <SidebarProvider>
        {/* Global Box Sizing and Admin Container */}
        <div className="admin-container flex min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
          {/* Sidebar - Fixed Width 250px */}
          <AdminSidebar />

          {/* Main Content - Takes Remaining Space */}
          <main className="main-content flex-1 flex flex-col min-h-screen overflow-hidden">
            {/* Header */}
            <AdminHeader />

            {/* Content Area - Scrollable */}
            <div className="flex-1 p-4 lg:p-8 overflow-y-auto">
              <div className="w-full">
                <ErrorBoundary
                  fallback={
                    <div className="flex items-center justify-center min-h-[400px]">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-red-600 dark:text-red-400 text-2xl">⚠</span>
                        </div>
                        <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                          Something went wrong
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400">
                          Please refresh the page or contact support if the problem persists.
                        </p>
                      </div>
                    </div>
                  }
                >
                  <Suspense fallback={<LoadingSpinner />}>{children}</Suspense>
                </ErrorBoundary>
              </div>
            </div>
          </main>

          {/* Mobile Bottom Navigation */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 z-50 shadow-lg">
            <div className="flex justify-around p-2">
              <Suspense
                fallback={
                  <div className="flex justify-around w-full">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex flex-col items-center p-3 space-y-1">
                        <div className="w-5 h-5 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                        <div className="w-12 h-3 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                      </div>
                    ))}
                  </div>
                }
              >
                <AdminMobileNav />
              </Suspense>
            </div>
          </div>
        </div>

        {/* Global Styles for Box Sizing */}
        <style jsx global>{`
          *,
          *::before,
          *::after {
            box-sizing: border-box;
          }
          
          html,
          body {
            margin: 0;
            padding: 0;
            height: 100%;
          }
          
          .admin-container {
            box-sizing: border-box;
          }
          
          .sidebar {
            box-sizing: border-box;
            flex-shrink: 0;
          }
          
          .main-content {
            box-sizing: border-box;
            min-width: 0; /* Prevents flex item from overflowing */
          }
          
          /* Responsive breakpoints */
          @media (max-width: 767px) {
            .sidebar {
              display: none;
            }
            
            .main-content {
              width: 100%;
              margin-left: 0;
            }
          }
          
          @media (min-width: 768px) {
            .sidebar {
              width: 256px; /* 64 * 0.25rem = 16rem = 256px */
            }
            
            .main-content {
              margin-left: 0; /* Flexbox handles spacing automatically */
            }
          }
          
          /* Scrollbar styling for webkit browsers */
          .sidebar::-webkit-scrollbar,
          .main-content::-webkit-scrollbar {
            width: 6px;
          }
          
          .sidebar::-webkit-scrollbar-track,
          .main-content::-webkit-scrollbar-track {
            background: transparent;
          }
          
          .sidebar::-webkit-scrollbar-thumb,
          .main-content::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.3);
            border-radius: 3px;
          }
          
          .sidebar::-webkit-scrollbar-thumb:hover,
          .main-content::-webkit-scrollbar-thumb:hover {
            background: rgba(148, 163, 184, 0.5);
          }
          
          /* Dark theme scrollbar */
          .dark .sidebar::-webkit-scrollbar-thumb,
          .dark .main-content::-webkit-scrollbar-thumb {
            background: rgba(71, 85, 105, 0.3);
          }
          
          .dark .sidebar::-webkit-scrollbar-thumb:hover,
          .dark .main-content::-webkit-scrollbar-thumb:hover {
            background: rgba(71, 85, 105, 0.5);
          }
        `}</style>
      </SidebarProvider>
    </ErrorBoundary>
  )
}
