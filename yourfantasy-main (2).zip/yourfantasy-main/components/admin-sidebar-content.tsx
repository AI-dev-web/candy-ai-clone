"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  CreditCard,
  Database,
  ImageIcon,
  LayoutDashboard,
  MessageSquare,
  Settings,
  Users,
  FileText,
  DollarSign,
  Megaphone,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface AdminSidebarContentProps {
  className?: string
}

export function AdminSidebarContent({ className }: AdminSidebarContentProps) {
  const pathname = usePathname()

  const routes = [
    {
      href: "/admin/dashboard",
      icon: LayoutDashboard,
      title: "Dashboard",
      description: "Overview & Analytics",
      badge: null,
      category: "main",
    },
    {
      href: "/admin/dashboard/characters",
      icon: MessageSquare,
      title: "Characters",
      description: "AI Character Management",
      badge: null,
      category: "main",
    },
    {
      href: "/admin/dashboard/users",
      icon: Users,
      title: "Users",
      description: "User Management",
      badge: null,
      category: "main",
    },
    {
      href: "/admin/dashboard/api-keys",
      icon: FileText,
      title: "API Keys",
      description: "API Configuration",
      badge: null,
      category: "main",
    },
    {
      href: "/admin/dashboard/image-suggestions",
      icon: ImageIcon,
      title: "Image Suggestions",
      description: "Image Management",
      badge: null,
      category: "content",
    },
    {
      href: "/admin/dashboard/banners",
      icon: Megaphone,
      title: "Banners",
      description: "Promotional Content",
      badge: null,
      category: "content",
    },
    {
      href: "/admin/dashboard/subscriptions",
      icon: CreditCard,
      title: "Subscriptions",
      description: "Subscription Plans",
      badge: null,
      category: "business",
    },
    {
      href: "/admin/dashboard/transactions",
      icon: DollarSign,
      title: "Transactions",
      description: "Payment History",
      badge: "New",
      category: "business",
    },
    {
      href: "/admin/dashboard/database",
      icon: Database,
      title: "Database",
      description: "Database Management",
      badge: null,
      category: "system",
    },
    {
      href: "/admin/settings",
      icon: Settings,
      title: "Settings",
      description: "System Configuration",
      badge: null,
      category: "system",
    },
  ]

  const categories = [
    { key: "main", title: "Main Menu", routes: routes.filter((r) => r.category === "main") },
    { key: "content", title: "Content Management", routes: routes.filter((r) => r.category === "content") },
    { key: "business", title: "Business", routes: routes.filter((r) => r.category === "business") },
    { key: "system", title: "System", routes: routes.filter((r) => r.category === "system") },
  ]

  return (
    <div className={cn("flex w-full flex-col gap-2", className)}>
      {categories.map((category) => (
        <div key={category.key} className="mb-4">
          <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
            {category.title}
          </h3>
          <div className="space-y-1">
            {category.routes.map((route) => {
              const isActive =
                pathname === route.href || (route.href !== "/admin/dashboard" && pathname?.startsWith(`${route.href}/`))
              return (
                <Button
                  key={route.href}
                  variant="ghost"
                  className={cn(
                    "w-full justify-start h-auto p-3 text-left hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-200 group",
                    isActive &&
                      "bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-r-2 border-purple-500 text-purple-700 dark:text-purple-300",
                  )}
                  asChild
                >
                  <Link href={route.href}>
                    <div className="flex items-center w-full">
                      <route.icon
                        className={cn(
                          "h-5 w-5 mr-3 flex-shrink-0 transition-colors",
                          isActive
                            ? "text-purple-600 dark:text-purple-400"
                            : "text-slate-500 dark:text-slate-400 group-hover:text-purple-500 dark:group-hover:text-purple-400",
                        )}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span
                            className={cn(
                              "font-medium text-sm transition-colors",
                              isActive
                                ? "text-purple-700 dark:text-purple-300"
                                : "text-slate-700 dark:text-slate-300 group-hover:text-purple-600 dark:group-hover:text-purple-300",
                            )}
                          >
                            {route.title}
                          </span>
                          {route.badge && (
                            <Badge
                              variant="secondary"
                              className="ml-2 text-xs bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300"
                            >
                              {route.badge}
                            </Badge>
                          )}
                        </div>
                        <p
                          className={cn(
                            "text-xs mt-0.5 transition-colors",
                            isActive
                              ? "text-purple-600 dark:text-purple-400"
                              : "text-slate-500 dark:text-slate-400 group-hover:text-purple-500 dark:group-hover:text-purple-400",
                          )}
                        >
                          {route.description}
                        </p>
                      </div>
                    </div>
                  </Link>
                </Button>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}

export default AdminSidebarContent
